import { useState, useEffect, useRef } from "react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

const COLORS = {
  alimentacao: "#F97316",
  combustivel: "#3B82F6",
  lazer: "#A855F7",
  moradia: "#10B981",
  outros: "#6B7280",
};
const CAT_LABELS = {
  alimentacao: "🍔 Alimentação",
  combustivel: "⛽ Combustível",
  lazer: "🎉 Lazer",
  moradia: "🏠 Moradia",
  outros: "📦 Outros",
};
const fmt = (v) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v ?? 0);
const today = () => new Date().toISOString().split("T")[0];

async function ocrWithClaude(base64, mimeType) {
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 300,
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mimeType, data: base64 } },
            {
              type: "text",
              text: `Analise esta imagem (nota fiscal, cupom, extrato bancário ou limite de cartão).
Responda SOMENTE em JSON válido, sem markdown:
{
  "tipo": "nota_fiscal" | "saldo_bancario" | "limite_cartao" | "outro",
  "valor_total": número ou null,
  "saldo": número ou null,
  "limite_disponivel": número ou null,
  "limite_total": número ou null,
  "descricao": "texto curto"
}`
            }
          ]
        }]
      })
    });
    const data = await res.json();
    const raw = data?.content?.[0]?.text ?? "";
    return JSON.parse(raw.replace(/```json|```/g, "").trim());
  } catch { return null; }
}

const LS = {
  get: (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set: (k, v) => localStorage.setItem(k, JSON.stringify(v)),
};

export default function App() {
  const [user, setUser] = useState(() => LS.get("fin_user", null));
  const [authMode, setAuthMode] = useState("login");
  const [authForm, setAuthForm] = useState({ email: "", senha: "" });
  const [authErr, setAuthErr] = useState("");
  const [screen, setScreen] = useState("home");
  const [transactions, setTransactions] = useState([]);
  const [images, setImages] = useState([]);
  const [notifSent, setNotifSent] = useState(false);

  useEffect(() => {
    if (user) {
      setTransactions(LS.get(`fin_tx_${user.email}`, []));
      setImages(LS.get(`fin_imgs_${user.email}`, []));
    }
  }, [user]);

  useEffect(() => { if (user) LS.set(`fin_tx_${user.email}`, transactions); }, [transactions, user]);
  useEffect(() => { if (user) LS.set(`fin_imgs_${user.email}`, images); }, [images, user]);

  const totalEntradas = transactions.filter(t => t.tipo === "entrada").reduce((a, t) => a + t.valor, 0);
  const totalGastos = transactions.filter(t => t.tipo === "gasto").reduce((a, t) => a + t.valor, 0);
  const saldo = totalEntradas - totalGastos;

  useEffect(() => {
    if (saldo < 1000 && !notifSent && transactions.length > 0) {
      setNotifSent(true);
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification("⚠️ Saldo Baixo!", { body: `Seu saldo está em ${fmt(saldo)}. Abaixo de R$ 1.000,00!` });
      }
    }
    if (saldo >= 1000) setNotifSent(false);
  }, [saldo, notifSent, transactions.length]);

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  const handleAuth = () => {
    const users = LS.get("fin_users", {});
    if (!authForm.email || !authForm.senha) return setAuthErr("Preencha todos os campos.");
    if (authMode === "login") {
      if (!users[authForm.email] || users[authForm.email] !== authForm.senha)
        return setAuthErr("Email ou senha incorretos.");
      const u = { email: authForm.email };
      setUser(u); LS.set("fin_user", u);
    } else {
      if (users[authForm.email]) return setAuthErr("Email já cadastrado.");
      users[authForm.email] = authForm.senha;
      LS.set("fin_users", users);
      const u = { email: authForm.email };
      setUser(u); LS.set("fin_user", u);
    }
    setAuthErr("");
  };

  const logout = () => { setUser(null); LS.set("fin_user", null); setTransactions([]); setImages([]); };
  const addTx = (tx) => setTransactions(p => [{ ...tx, id: Date.now() }, ...p]);
  const delTx = (id) => setTransactions(p => p.filter(t => t.id !== id));
  const addImage = (img) => setImages(p => [img, ...p]);
  const delImage = (id) => setImages(p => p.filter(i => i.id !== id));

  if (!user) return <AuthScreen mode={authMode} form={authForm} err={authErr}
    setForm={setAuthForm} setMode={setAuthMode} onSubmit={handleAuth} />;

  return (
    <div style={S.shell}>
      <div style={S.statusBar}>
        <span style={{ fontSize: 13, fontWeight: 700 }}>💰 FinanceFlow</span>
        <span style={{ fontSize: 11, opacity: 0.7, maxWidth: 180, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user.email}</span>
      </div>
      <div style={S.content}>
        {screen === "home" && <HomeScreen transactions={transactions} saldo={saldo} totalEntradas={totalEntradas} totalGastos={totalGastos} delTx={delTx} setScreen={setScreen} images={images} />}
        {screen === "add" && <AddScreen onAdd={addTx} setScreen={setScreen} />}
        {screen === "scan" && <ScanScreen onAdd={addTx} setScreen={setScreen} />}
        {screen === "report" && <ReportScreen transactions={transactions} saldo={saldo} totalEntradas={totalEntradas} totalGastos={totalGastos} />}
        {screen === "images" && <ImagesScreen images={images} addImage={addImage} delImage={delImage} />}
        {screen === "profile" && <ProfileScreen user={user} onLogout={logout} />}
      </div>
      <nav style={S.nav}>
        {[
          { s: "home", icon: "🏠", label: "Início" },
          { s: "add", icon: "➕", label: "Lançar" },
          { s: "scan", icon: "📷", label: "Nota" },
          { s: "images", icon: "🖼️", label: "Extratos" },
          { s: "report", icon: "📊", label: "Relatório" },
          { s: "profile", icon: "👤", label: "Perfil" },
        ].map(({ s, icon, label }) => (
          <button key={s} onClick={() => setScreen(s)} style={{ ...S.navBtn, ...(screen === s ? S.navBtnActive : {}) }}>
            <span style={{ fontSize: 22 }}>{icon}</span>
            <span style={{ fontSize: 10, marginTop: 2 }}>{label}</span>
          </button>
        ))}
      </nav>
      {saldo < 1000 && saldo >= 0 && transactions.length > 0 && (
        <div style={S.alertBanner}>⚠️ Saldo baixo: {fmt(saldo)}</div>
      )}
    </div>
  );
}

function AuthScreen({ mode, form, err, setForm, setMode, onSubmit }) {
  return (
    <div style={{ ...S.shell, justifyContent: "center", alignItems: "center", background: "linear-gradient(160deg,#0f172a,#1e3a5f)" }}>
      <div style={S.authCard}>
        <div style={{ fontSize: 60, textAlign: "center" }}>💰</div>
        <h1 style={{ color: "#fff", textAlign: "center", fontSize: 28, margin: "8px 0 4px" }}>FinanceFlow</h1>
        <p style={{ color: "rgba(255,255,255,0.5)", textAlign: "center", fontSize: 14, marginBottom: 24 }}>Controle financeiro inteligente</p>
        <input style={S.input} placeholder="Email" type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} />
        <input style={S.input} placeholder="Senha" type="password" value={form.senha} onChange={e => setForm(p => ({ ...p, senha: e.target.value }))} onKeyDown={e => e.key === "Enter" && onSubmit()} />
        {err && <p style={{ color: "#f87171", fontSize: 13, margin: "4px 0 8px" }}>{err}</p>}
        <button style={S.primaryBtn} onClick={onSubmit}>{mode === "login" ? "Entrar" : "Criar Conta"}</button>
        <button style={S.ghostBtn} onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "Não tem conta? Cadastre-se" : "Já tem conta? Entrar"}
        </button>
      </div>
    </div>
  );
}

function HomeScreen({ transactions, saldo, totalEntradas, totalGastos, delTx, setScreen, images }) {
  return (
    <div style={S.screen}>
      <div style={S.balanceCard}>
        <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, margin: 0 }}>Saldo Disponível</p>
        <h2 style={{ color: saldo < 1000 ? "#fbbf24" : "#fff", fontSize: 34, margin: "4px 0", fontFamily: "monospace" }}>{fmt(saldo)}</h2>
        {saldo < 1000 && <p style={{ color: "#fbbf24", fontSize: 12, margin: 0 }}>⚠️ Saldo baixo!</p>}
        <div style={{ display: "flex", gap: 32, marginTop: 16 }}>
          <div>
            <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, margin: 0 }}>Entradas</p>
            <p style={{ color: "#4ade80", fontSize: 16, margin: 0, fontWeight: 700 }}>{fmt(totalEntradas)}</p>
          </div>
          <div>
            <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, margin: 0 }}>Gastos</p>
            <p style={{ color: "#f87171", fontSize: 16, margin: 0, fontWeight: 700 }}>{fmt(totalGastos)}</p>
          </div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <button style={{ ...S.quickBtn, flex: 1 }} onClick={() => setScreen("add")}>➕ Lançar</button>
        <button style={{ ...S.quickBtn, flex: 1, background: "#7c3aed" }} onClick={() => setScreen("scan")}>📷 Nota</button>
        <button style={{ ...S.quickBtn, flex: 1, background: "#0369a1" }} onClick={() => setScreen("images")}>🖼️ Extrato</button>
      </div>

      {images.length > 0 && (
        <div style={S.card}>
          <p style={S.sectionTitle}>📌 Extratos & Limites salvos</p>
          {images.slice(0, 3).map(img => (
            <div key={img.id} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #f3f4f6", fontSize: 14 }}>
              <span>{img.label}</span>
              {img.valor != null && <span style={{ fontWeight: 700, color: "#0369a1" }}>{fmt(img.valor)}</span>}
            </div>
          ))}
          {images.length > 3 && <p style={{ fontSize: 12, color: "#9ca3af", textAlign: "center", marginTop: 6 }}>+{images.length - 3} mais na aba Extratos</p>}
        </div>
      )}

      <p style={S.sectionTitle}>Lançamentos Recentes</p>
      {transactions.length === 0 && <p style={{ color: "#9ca3af", textAlign: "center", fontSize: 14, padding: "20px 0" }}>Nenhum lançamento ainda. Toque em ➕ para começar!</p>}
      {transactions.slice(0, 30).map(tx => (
        <div key={tx.id} style={S.txRow}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 42, height: 42, borderRadius: 12, background: tx.tipo === "entrada" ? "#dcfce7" : "#fee2e2", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>
              {tx.tipo === "entrada" ? "📈" : (CAT_LABELS[tx.categoria]?.split(" ")[0] ?? "💸")}
            </div>
            <div>
              <p style={{ margin: 0, fontWeight: 600, fontSize: 14 }}>{tx.tipo === "entrada" ? "Entrada" : (CAT_LABELS[tx.categoria] ?? tx.categoria)}</p>
              <p style={{ margin: 0, fontSize: 11, color: "#9ca3af" }}>{tx.data}{tx.obs ? ` • ${tx.obs}` : ""}</p>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontWeight: 700, color: tx.tipo === "entrada" ? "#16a34a" : "#dc2626" }}>
              {tx.tipo === "entrada" ? "+" : "-"}{fmt(tx.valor)}
            </span>
            <button onClick={() => delTx(tx.id)} style={S.delBtn}>✕</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function AddScreen({ onAdd, setScreen }) {
  const [form, setForm] = useState({ tipo: "gasto", categoria: "alimentacao", valor: "", data: today(), obs: "" });
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const submit = () => {
    const v = parseFloat(form.valor.replace(",", "."));
    if (!v || v <= 0) return alert("Informe um valor válido.");
    onAdd({ ...form, valor: v });
    setScreen("home");
  };
  return (
    <div style={S.screen}>
      <h2 style={S.pageTitle}>Novo Lançamento</h2>
      <div style={S.card}>
        <label style={S.label}>Tipo</label>
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          {["entrada", "gasto"].map(t => (
            <button key={t} onClick={() => set("tipo", t)} style={{ flex: 1, padding: "12px 0", borderRadius: 12, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 15, background: form.tipo === t ? (t === "entrada" ? "#16a34a" : "#dc2626") : "#f3f4f6", color: form.tipo === t ? "#fff" : "#374151" }}>
              {t === "entrada" ? "💚 Entrada" : "🔴 Gasto"}
            </button>
          ))}
        </div>
        {form.tipo === "gasto" && (
          <>
            <label style={S.label}>Categoria</label>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 14 }}>
              {Object.entries(CAT_LABELS).map(([k, v]) => (
                <button key={k} onClick={() => set("categoria", k)} style={{ padding: "7px 14px", borderRadius: 20, border: "none", cursor: "pointer", fontSize: 13, background: form.categoria === k ? COLORS[k] : "#f3f4f6", color: form.categoria === k ? "#fff" : "#374151", fontWeight: form.categoria === k ? 700 : 400 }}>
                  {v}
                </button>
              ))}
            </div>
          </>
        )}
        <label style={S.label}>Valor (R$)</label>
        <input style={S.input} type="number" inputMode="decimal" placeholder="0,00" value={form.valor} onChange={e => set("valor", e.target.value)} />
        <label style={S.label}>Data</label>
        <input style={S.input} type="date" value={form.data} onChange={e => set("data", e.target.value)} />
        <label style={S.label}>Observação (opcional)</label>
        <input style={S.input} placeholder="Ex: Supermercado, Posto Shell..." value={form.obs} onChange={e => set("obs", e.target.value)} />
        <button style={S.primaryBtn} onClick={submit}>✅ Salvar Lançamento</button>
      </div>
    </div>
  );
}

function ScanScreen({ onAdd, setScreen }) {
  const [img, setImg] = useState(null);
  const [base64, setBase64] = useState(null);
  const [mime, setMime] = useState("image/jpeg");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [form, setForm] = useState({ categoria: "alimentacao", obs: "", data: today() });
  const fileRef = useRef();

  const handleFile = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    setMime(f.type || "image/jpeg");
    const reader = new FileReader();
    reader.onload = (ev) => { setImg(ev.target.result); setBase64(ev.target.result.split(",")[1]); setResult(null); };
    reader.readAsDataURL(f);
  };

  const analyze = async () => {
    if (!base64) return;
    setLoading(true);
    const r = await ocrWithClaude(base64, mime);
    setLoading(false);
    setResult(r || { tipo: "outro", descricao: "Não foi possível identificar o valor." });
  };

  const confirm = () => {
    const v = result?.valor_total;
    if (!v) return alert("Valor não detectado automaticamente. Por favor, lance manualmente.");
    onAdd({ tipo: "gasto", categoria: form.categoria, valor: v, data: form.data, obs: form.obs || result?.descricao });
    setScreen("home");
  };

  return (
    <div style={S.screen}>
      <h2 style={S.pageTitle}>📷 Escanear Nota Fiscal</h2>
      <div style={S.card}>
        <div style={S.scanBox} onClick={() => fileRef.current.click()}>
          {img
            ? <img src={img} alt="nota" style={{ width: "100%", borderRadius: 10 }} />
            : <div style={{ textAlign: "center", color: "#94a3b8" }}><div style={{ fontSize: 52 }}>📄</div><p style={{ margin: "8px 0 0", fontSize: 14 }}>Toque para fotografar a nota fiscal</p><p style={{ margin: 4, fontSize: 12, opacity: 0.7 }}>ou escolha da galeria</p></div>
          }
        </div>
        <input ref={fileRef} type="file" accept="image/*" capture="environment" onChange={handleFile} style={{ display: "none" }} />
        {img && !result && (
          <button style={S.primaryBtn} onClick={analyze} disabled={loading}>
            {loading ? "🔍 Analisando com IA..." : "🔍 Analisar Nota Fiscal"}
          </button>
        )}
        {result && (
          <div style={{ marginTop: 12 }}>
            <div style={{ background: "#eff6ff", border: "1px solid #bfdbfe", borderRadius: 12, padding: 14, marginBottom: 12 }}>
              <p style={{ margin: 0, fontWeight: 700, color: "#1e40af" }}>Resultado da análise:</p>
              <p style={{ margin: "4px 0", fontSize: 13, color: "#374151" }}>{result.descricao}</p>
              {result.valor_total
                ? <p style={{ margin: "8px 0 0", fontSize: 24, fontWeight: 800, color: "#dc2626" }}>💸 {fmt(result.valor_total)}</p>
                : <p style={{ margin: "8px 0 0", fontSize: 13, color: "#dc2626" }}>⚠️ Valor não detectado — lance manualmente.</p>
              }
            </div>
            <label style={S.label}>Categoria</label>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 12 }}>
              {Object.entries(CAT_LABELS).map(([k, v]) => (
                <button key={k} onClick={() => setForm(p => ({ ...p, categoria: k }))} style={{ padding: "6px 12px", borderRadius: 20, border: "none", cursor: "pointer", fontSize: 13, background: form.categoria === k ? COLORS[k] : "#f3f4f6", color: form.categoria === k ? "#fff" : "#374151" }}>
                  {v}
                </button>
              ))}
            </div>
            <label style={S.label}>Observação</label>
            <input style={S.input} value={form.obs} placeholder="Detalhe opcional..." onChange={e => setForm(p => ({ ...p, obs: e.target.value }))} />
            <label style={S.label}>Data</label>
            <input style={S.input} type="date" value={form.data} onChange={e => setForm(p => ({ ...p, data: e.target.value }))} />
            {result.valor_total && <button style={S.primaryBtn} onClick={confirm}>✅ Adicionar gasto de {fmt(result.valor_total)}</button>}
          </div>
        )}
      </div>
    </div>
  );
}

function ImagesScreen({ images, addImage, delImage }) {
  const [img, setImg] = useState(null);
  const [base64, setBase64] = useState(null);
  const [mime, setMime] = useState("image/jpeg");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [label, setLabel] = useState("");
  const fileRef = useRef();

  const handleFile = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    setMime(f.type || "image/jpeg");
    const reader = new FileReader();
    reader.onload = (ev) => { setImg(ev.target.result); setBase64(ev.target.result.split(",")[1]); setResult(null); setLabel(""); };
    reader.readAsDataURL(f);
  };

  const analyze = async () => {
    setLoading(true);
    const r = await ocrWithClaude(base64, mime);
    setLoading(false);
    if (r) { setResult(r); setLabel(r.descricao || ""); }
    else setResult({ tipo: "outro", descricao: "Não identificado" });
  };

  const save = () => {
    const valor = result?.saldo ?? result?.limite_disponivel ?? result?.valor_total ?? null;
    addImage({ id: Date.now(), src: img, label: label || "Sem título", tipo: result?.tipo, valor, limite_total: result?.limite_total, data: today() });
    setImg(null); setBase64(null); setResult(null); setLabel("");
  };

  return (
    <div style={S.screen}>
      <h2 style={S.pageTitle}>🖼️ Extratos & Limites</h2>
      <div style={S.card}>
        <p style={{ margin: "0 0 10px", fontWeight: 600, fontSize: 15 }}>Adicionar print de saldo ou limite</p>
        <div style={S.scanBox} onClick={() => fileRef.current.click()}>
          {img
            ? <img src={img} alt="extrato" style={{ width: "100%", borderRadius: 10 }} />
            : <div style={{ textAlign: "center", color: "#94a3b8" }}><div style={{ fontSize: 48 }}>🏦</div><p style={{ margin: "8px 0 0", fontSize: 14 }}>Print do saldo bancário</p><p style={{ fontSize: 12, opacity: 0.7 }}>ou limite de cartão de crédito</p></div>
          }
        </div>
        <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} style={{ display: "none" }} />
        {img && !result && (
          <button style={S.primaryBtn} onClick={analyze} disabled={loading}>
            {loading ? "🔍 Identificando..." : "🔍 Identificar com IA"}
          </button>
        )}
        {result && (
          <div>
            <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 12, padding: 14, marginBottom: 12 }}>
              <p style={{ margin: 0, fontWeight: 700 }}>{result.descricao}</p>
              {result.saldo != null && <p style={{ margin: "4px 0 0" }}>💰 Saldo: <b style={{ color: "#16a34a" }}>{fmt(result.saldo)}</b></p>}
              {result.limite_disponivel != null && <p style={{ margin: "4px 0 0" }}>💳 Limite disponível: <b style={{ color: "#0369a1" }}>{fmt(result.limite_disponivel)}</b></p>}
              {result.limite_total != null && <p style={{ margin: "4px 0 0" }}>💳 Limite total: <b>{fmt(result.limite_total)}</b></p>}
            </div>
            <label style={S.label}>Descrição / Rótulo</label>
            <input style={S.input} value={label} onChange={e => setLabel(e.target.value)} placeholder="Ex: Nubank, Bradesco CC..." />
            <button style={S.primaryBtn} onClick={save}>💾 Salvar</button>
          </div>
        )}
      </div>

      {images.length === 0 && <p style={{ color: "#9ca3af", textAlign: "center", fontSize: 14, padding: "20px 0" }}>Nenhum extrato salvo ainda.</p>}
      {images.map(img => (
        <div key={img.id} style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <span style={{ fontWeight: 700, fontSize: 15 }}>{img.label}</span>
            <button onClick={() => delImage(img.id)} style={S.delBtn}>✕</button>
          </div>
          <img src={img.src} alt={img.label} style={{ width: "100%", borderRadius: 10, marginBottom: 8 }} />
          <div style={{ display: "flex", gap: 16, fontSize: 13 }}>
            {img.valor != null && <span>💰 <b style={{ color: "#0369a1" }}>{fmt(img.valor)}</b></span>}
            {img.limite_total != null && <span>💳 <b>{fmt(img.limite_total)}</b></span>}
            <span style={{ color: "#9ca3af", marginLeft: "auto" }}>{img.data}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

function ReportScreen({ transactions, saldo, totalEntradas, totalGastos }) {
  const [period, setPeriod] = useState("mes");
  const now = new Date();
  const filtered = transactions.filter(tx => {
    const d = new Date(tx.data + "T12:00:00");
    if (period === "mes") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    if (period === "semana") return (now - d) / 86400000 <= 7;
    return true;
  });
  const gastos = filtered.filter(t => t.tipo === "gasto");
  const totalG = gastos.reduce((a, t) => a + t.valor, 0);
  const totalE = filtered.filter(t => t.tipo === "entrada").reduce((a, t) => a + t.valor, 0);
  const byCat = {};
  gastos.forEach(t => { byCat[t.categoria] = (byCat[t.categoria] || 0) + t.valor; });
  const pieData = Object.entries(byCat).map(([k, v]) => ({ name: CAT_LABELS[k] ?? k, value: v, color: COLORS[k] }));
  const byDay = {};
  filtered.forEach(t => {
    byDay[t.data] = byDay[t.data] || { data: t.data, entradas: 0, gastos: 0 };
    if (t.tipo === "entrada") byDay[t.data].entradas += t.valor;
    else byDay[t.data].gastos += t.valor;
  });
  const barData = Object.values(byDay).sort((a, b) => a.data.localeCompare(b.data)).slice(-10).map(d => ({ ...d, data: d.data.slice(5) }));

  return (
    <div style={S.screen}>
      <h2 style={S.pageTitle}>📊 Relatório</h2>
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        {[["semana", "7 dias"], ["mes", "Este mês"], ["todos", "Tudo"]].map(([v, l]) => (
          <button key={v} onClick={() => setPeriod(v)} style={{ flex: 1, padding: "9px 0", borderRadius: 10, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600, background: period === v ? "#0f172a" : "#f3f4f6", color: period === v ? "#fff" : "#374151" }}>{l}</button>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
        {[
          { label: "Entradas", value: totalE, color: "#16a34a", bg: "#dcfce7" },
          { label: "Gastos", value: totalG, color: "#dc2626", bg: "#fee2e2" },
          { label: "Saldo Geral", value: saldo, color: saldo >= 0 ? "#0369a1" : "#dc2626", bg: "#dbeafe" },
          { label: "Transações", value: filtered.length, color: "#7c3aed", bg: "#ede9fe", isCount: true },
        ].map(({ label, value, color, bg, isCount }) => (
          <div key={label} style={{ background: bg, borderRadius: 14, padding: "14px 16px" }}>
            <p style={{ margin: 0, fontSize: 12, color: "#6b7280" }}>{label}</p>
            <p style={{ margin: "4px 0 0", fontSize: 18, fontWeight: 800, color }}>{isCount ? value : fmt(value)}</p>
          </div>
        ))}
      </div>
      {pieData.length > 0 && (
        <div style={S.card}>
          <p style={S.sectionTitle}>Gastos por Categoria</p>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" outerRadius={75} dataKey="value" label={({ percent }) => `${(percent * 100).toFixed(0)}%`}>
                {pieData.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip formatter={v => fmt(v)} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}
      {barData.length > 0 && (
        <div style={S.card}>
          <p style={S.sectionTitle}>Entradas × Gastos por Dia</p>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={barData}>
              <XAxis dataKey="data" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={v => fmt(v)} />
              <Bar dataKey="entradas" name="Entradas" fill="#4ade80" radius={[4, 4, 0, 0]} />
              <Bar dataKey="gastos" name="Gastos" fill="#f87171" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
      {pieData.length > 0 && (
        <div style={S.card}>
          <p style={S.sectionTitle}>Detalhamento por Categoria</p>
          {Object.entries(byCat).sort((a, b) => b[1] - a[1]).map(([k, v]) => (
            <div key={k} style={{ marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 }}>
                <span>{CAT_LABELS[k]}</span>
                <span style={{ fontWeight: 700 }}>{fmt(v)} ({totalG > 0 ? ((v / totalG) * 100).toFixed(1) : 0}%)</span>
              </div>
              <div style={{ height: 7, background: "#f3f4f6", borderRadius: 10, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${totalG > 0 ? (v / totalG) * 100 : 0}%`, background: COLORS[k], borderRadius: 10 }} />
              </div>
            </div>
          ))}
        </div>
      )}
      {filtered.length === 0 && <p style={{ color: "#9ca3af", textAlign: "center", fontSize: 14, padding: "20px 0" }}>Sem dados para este período.</p>}
    </div>
  );
}

function ProfileScreen({ user, onLogout }) {
  return (
    <div style={S.screen}>
      <h2 style={S.pageTitle}>👤 Perfil</h2>
      <div style={S.card}>
        <div style={{ textAlign: "center", padding: 20 }}>
          <div style={{ fontSize: 64 }}>👤</div>
          <p style={{ fontWeight: 700, fontSize: 18, margin: "8px 0 4px" }}>{user.email}</p>
          <p style={{ color: "#16a34a", fontSize: 13 }}>✅ Conta ativa</p>
        </div>
        <div style={{ borderTop: "1px solid #f3f4f6", paddingTop: 16, lineHeight: 2 }}>
          <p style={{ fontSize: 14, color: "#374151" }}>✅ Dados salvos por email</p>
          <p style={{ fontSize: 14, color: "#374151" }}>✅ Notificação de saldo baixo (&lt; R$ 1.000)</p>
          <p style={{ fontSize: 14, color: "#374151" }}>✅ OCR de notas fiscais com IA</p>
          <p style={{ fontSize: 14, color: "#374151" }}>✅ Gráficos e relatórios por categoria</p>
          <p style={{ fontSize: 14, color: "#374151" }}>✅ Prints de extrato e limite de cartão</p>
        </div>
        <button style={{ ...S.primaryBtn, background: "#dc2626", marginTop: 16 }} onClick={onLogout}>🚪 Sair da conta</button>
      </div>
    </div>
  );
}

const S = {
  shell: { maxWidth: 430, margin: "0 auto", minHeight: "100vh", background: "#f8fafc", display: "flex", flexDirection: "column", fontFamily: "'Segoe UI', system-ui, sans-serif", position: "relative" },
  statusBar: { background: "#0f172a", color: "#fff", padding: "10px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" },
  content: { flex: 1, overflowY: "auto", paddingBottom: 90 },
  screen: { padding: "16px 16px 0" },
  nav: { position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 430, background: "#fff", borderTop: "1px solid #e5e7eb", display: "flex", boxShadow: "0 -4px 20px rgba(0,0,0,0.08)", zIndex: 100 },
  navBtn: { flex: 1, border: "none", background: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", padding: "10px 0", color: "#9ca3af" },
  navBtnActive: { color: "#0f172a" },
  alertBanner: { position: "fixed", top: 44, left: "50%", transform: "translateX(-50%)", background: "#fbbf24", color: "#78350f", padding: "8px 20px", borderRadius: 20, fontSize: 13, fontWeight: 700, zIndex: 200, boxShadow: "0 4px 15px rgba(251,191,36,0.4)", whiteSpace: "nowrap" },
  balanceCard: { background: "linear-gradient(135deg,#1e3a5f,#0f172a)", borderRadius: 20, padding: "24px 20px", marginBottom: 16, boxShadow: "0 8px 30px rgba(15,23,42,0.3)" },
  card: { background: "#fff", borderRadius: 16, padding: 16, marginBottom: 14, boxShadow: "0 2px 12px rgba(0,0,0,0.06)" },
  sectionTitle: { fontWeight: 700, fontSize: 15, margin: "0 0 10px", color: "#1e293b" },
  pageTitle: { fontSize: 22, fontWeight: 800, color: "#0f172a", margin: "0 0 16px" },
  txRow: { background: "#fff", borderRadius: 14, padding: "12px 14px", marginBottom: 8, display: "flex", alignItems: "center", justifyContent: "space-between", boxShadow: "0 1px 6px rgba(0,0,0,0.05)" },
  quickBtn: { background: "#1e3a5f", color: "#fff", border: "none", borderRadius: 12, padding: "12px 8px", fontWeight: 700, fontSize: 13, cursor: "pointer" },
  input: { width: "100%", padding: "12px 14px", borderRadius: 12, border: "1.5px solid #e5e7eb", fontSize: 15, marginBottom: 12, boxSizing: "border-box", outline: "none", background: "#f9fafb" },
  label: { display: "block", fontWeight: 600, fontSize: 13, color: "#374151", marginBottom: 6 },
  primaryBtn: { width: "100%", padding: "14px", borderRadius: 14, border: "none", cursor: "pointer", background: "#0f172a", color: "#fff", fontWeight: 700, fontSize: 16, marginTop: 4 },
  ghostBtn: { width: "100%", padding: "12px", borderRadius: 14, border: "1.5px solid rgba(255,255,255,0.2)", cursor: "pointer", background: "transparent", color: "rgba(255,255,255,0.7)", fontSize: 14, marginTop: 8 },
  delBtn: { background: "#fee2e2", color: "#dc2626", border: "none", borderRadius: 8, width: 28, height: 28, cursor: "pointer", fontWeight: 700, fontSize: 12 },
  authCard: { background: "rgba(255,255,255,0.07)", backdropFilter: "blur(20px)", borderRadius: 24, padding: "32px 24px", width: "90%", maxWidth: 360, border: "1px solid rgba(255,255,255,0.1)" },
  scanBox: { border: "2px dashed #cbd5e1", borderRadius: 14, padding: 16, cursor: "pointer", marginBottom: 12, minHeight: 150, display: "flex", alignItems: "center", justifyContent: "center" },
};
